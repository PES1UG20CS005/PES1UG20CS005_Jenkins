if(a>b)
{
    a=a+1;
    b=b-1;
}
a=a+b*a;